
True Type Font: LED Display-7 version 1.0


EULA
-==-
The font LED Display-7 is freeware for home using only.


DESCRIPTION
-=========-
This is original font created in style a LED (Light Emitting Diode) matrix 8*8 units. Native size is 25 points. Cyrillic code page is supported.

Files in led_display-7.zip:
       	readme.txt     			this file.
        led_display-7.ttf    		regular true type font;
	led_display-7_screen.png	preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


HINT
-==-
For emulation as background matrix use symbol "�" (press ALT+0153 on num pad).


FREEWARE USE (NOTES)
-=================-
Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-
Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: November 30 2012